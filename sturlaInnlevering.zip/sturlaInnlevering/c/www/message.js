function msg(){  
 alert("Hello Javatpoint");  
}  